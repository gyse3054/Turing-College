from setuptools import setup, find_packages

setup(
    name="GYS_PACKAGE",
    version="1.0.0",
    description="My calculator",
    author="Gytis Semenas",
    packages=find_packages(),
    install_requires=[
        
    ],
)